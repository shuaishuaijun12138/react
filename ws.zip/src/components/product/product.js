import React,{Component} from 'react';
import Nav from '../nav';
export default class Product extends Component{
    render(){
        return(
            <div>
                <Nav/>
                <h2>我是产品中心页面</h2>
            </div>
            
        )
    }
}